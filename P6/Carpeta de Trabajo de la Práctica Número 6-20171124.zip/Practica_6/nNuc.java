public class nNuc{
  public static void main(String[] args){
    int nProc = Runtime.getRuntime().availableProcessors();
    System.out.println("Nucleos disponibles: "+nProc);
  }
}

